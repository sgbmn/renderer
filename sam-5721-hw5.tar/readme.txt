To compile: make the makefile using the "make" comand
To run: run "./output"